import WotTest from "./WotTest";

test('WotTest.test01', async () => {
    const ris=await WotTest.test_01();
    expect(ris).toEqual(true);
});

test('WotTest.test03', async () => {
    const ris=await WotTest.test_03();
    expect(ris).toEqual(true);
});

test('WotTest.test04', async () => {
    const ris=await WotTest.test_04();
    expect(ris).toEqual(true);
});

test('WotTest.test05', async () => {
    const ris=await WotTest.test_05();
    expect(ris).toEqual(true);
});

test('WotTest.test06', async () => {
    const ris=await WotTest.test_06();
    expect(ris).toEqual(true);
});

test('WotTest.test07', async () => {
    const ris=await WotTest.test_07();
    expect(ris).toEqual(true);
});

test('WotTest.test08', async () => {
    const ris=await WotTest.test_08();
    expect(ris).toEqual(true);
});

test('WotTest.test09', async () => {
    const ris=await WotTest.test_09();
    expect(ris).toEqual(true);
});

test('WotTest.test10', async () => {
    const ris=await WotTest.test_10();
    expect(ris).toEqual(true);
});

test('WotTest.test11', async () => {
    const ris=await WotTest.test_11();
    expect(ris).toEqual(true);
});

test('WotTest.test12', async () => {
    const ris=await WotTest.test_12();
    expect(ris).toEqual(true);
});


test('WotTest.test13', async () => {
    const ris=await WotTest.test_13();
    expect(ris).toEqual(true);
});





